// main.cpp - Test application for TransformActions

// This application shows how to make simple animation using the classes TranslationAction,
// RotationAction, ScaleAction and ShearAction.

// Changelog
// Jul 09, 2008 - Bruno Schneider
// - Application created.

#include <vart/scene.h>
#include <vart/transform.h>
#include <vart/baseaction.h>
#include <vart/translationaction.h>
#include <vart/rotationaction.h>
#include <vart/scaleaction.h>
#include <vart/shearaction.h>
#include <vart/light.h>
#include <vart/sphere.h>
#include <vart/callback.h>
#include <vart/meshobject.h>
#include <vart/contrib/viewerglutogl.h>

#include <iostream>

using namespace std;

class MyIHClass : public VART::ViewerGlutOGL::IdleHandler
{
    public:
        MyIHClass() : rotPtr(NULL){}
        virtual ~MyIHClass() {}
        virtual void OnIdle() {
            rotation += 0.005;
            rotPtr->MakeXRotation(rotation);
            for(int i=0; i<10; i++){
                rotC[i].MakeXRotation(-rotation);
            }
            viewerPtr->PostRedisplay();
        }
        
    VART::Transform* rotPtr;
    vector<VART::Transform> rotC;
    private:
    double rotation = 0.0;
};

using namespace VART;       

// The application itself:
int main(int argc, char* argv[])
{
    VART::ViewerGlutOGL::Init(&argc, argv); // Initialize GLUT
    static VART::Scene scene; // create a scene
    static VART::ViewerGlutOGL viewer; // create a viewer (application window)
    // create a camera (scene observer)
    VART::Camera camera(Point4D(0,0,0), Point4D(0,0,0), Point4D::Y());
    MyIHClass idleHandler;

    list<VART::MeshObject*> objects;
    VART::MeshObject::ReadFromOBJ("ferris-wheel.obj", &objects);

    list<VART::MeshObject*>::iterator iter = objects.begin();
    vector<MeshObject*> objetos;
    for (; iter != objects.end(); ++iter) {
        objetos.push_back(*iter);
    }
    // Ordem:
    //  0 -> chair
    //  1 -> support
    //  2 -> wheel
    double angle = 2*M_PI/10;
    double raio = objetos[2]->GetBoundingBox().GetGreaterZ();
    vector<Transform> transC(10);
    vector<Transform> rotC(10);
    vector<MeshObject> cadeiras(10);
    MeshObject aux;
    for(int i=0; i<10;i++){
        aux = *objetos[0];
        aux.SetMaterial(Color::RANDOM());
        cadeiras[i] = aux;
        transC[i].MakeTranslation(Point4D(0,raio*sin(angle*i), raio*cos(angle*i)));
        transC[i].AddChild(cadeiras[i]);
        rotC[i].AddChild(transC[i]);
        objetos[2]->AddChild(rotC[i]);
    }
    
    Transform rotRoda;

    objetos[1]->AddChild(rotRoda);
    rotRoda.AddChild(*objetos[2]);
    
    scene.AddObject(objetos[1]);
    
    scene.AddCamera(&camera);
    scene.MakeCameraViewAll();

    idleHandler.rotPtr = &rotRoda;
    idleHandler.rotC = rotC;
    // Set up the viewer
    viewer.SetTitle("Roda Gigante");
    viewer.SetScene(scene); // attach the scene
    
    viewer.SetIdleHandler(&idleHandler); // attach the idle handler to the viewer

    scene.DrawLightsOGL(); // Set OpenGL's lights' state
    VART::ViewerGlutOGL::MainLoop(); // Enter main loop (event loop)
    return 0;
}
