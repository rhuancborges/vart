/// \file tranformaction.cpp
/// \brief Implementation file for V-ART class "TransformAction".
/// \version $Revision: 1.1 $

#include "vart/transformaction.h"

//#include <iostream>
using namespace std;

VART::TransformAction::TransformAction()
{
}
