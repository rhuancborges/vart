// main.cpp - keyboard handling example

// V-ART example: Keyboard handling

// This application controls the position of a sphere using keyboard (the four arrow keys).
// It shows a portable way to handle multiple keys pressed at the same time.

// Note: ViewerGlutOGL is part of "V-ART contrib".

// Changelog
// Oct 17, 2012 - Bruno de Oliveira Schneider
// - Application created.

#include <vart/scene.h>
#include <vart/light.h>
#include <vart/point4d.h>
#include <vart/sphere.h>
#include <vart/contrib/viewerglutogl.h>
#include <vart/meshobject.h>
#include <vart/box.h>

#include <iostream>

using namespace std;
using namespace VART;

const unsigned int MAX_KEYS = 10; // max number of keys to keep control
enum Key { UP, DOWN, RIGHT, LEFT };
bool keyPressed[MAX_KEYS];
const float PI = 3.141596;

// Define the keyboard handler
class KeyboardHandler : public ViewerGlutOGL::KbHandler
{
    public:
        KeyboardHandler() {
            for (unsigned int i = 0; i < MAX_KEYS; ++i)
                keyPressed[i] = false;
        }
        virtual void OnKeyDown(int key) {
            switch (key) {
                case KEY_LEFT:
                    keyPressed[LEFT] = true;
                    break;
                case 'l':
                    keyPressed[LEFT] = true;
                    break;
                case KEY_RIGHT:
                    keyPressed[RIGHT] = true;
                    break;
                case 'j':
                    keyPressed[RIGHT] = true;
                    break;
                case KEY_UP:
                    keyPressed[UP] = true;
                    break;
                case 'i':
                    keyPressed[UP] = true;
                    break;
                case KEY_DOWN:
                    keyPressed[DOWN] = true;
                    break;
                case 'k':
                    keyPressed[DOWN] = true;
                    break;
            
            }
        }
        virtual void OnKeyUp(int key) {
            switch (key) {
                case KEY_LEFT:
                    keyPressed[LEFT] = false;
                    break;
                case 'l':
                    keyPressed[LEFT] = false;
                    break;
                case KEY_RIGHT:
                    keyPressed[RIGHT] = false;
                    break;
                case 'j':
                    keyPressed[RIGHT] = false;
                    break;
                case KEY_UP:
                    keyPressed[UP] = false;
                    break;
                case 'i':
                    keyPressed[UP] = false;
                    break;
                case KEY_DOWN:
                    keyPressed[DOWN] = false;
                    break;
                case 'k':
                    keyPressed[DOWN] = false;
                    break;
            }
        }
    private:
};

class MyIHClass : public VART::ViewerGlutOGL::IdleHandler
{
    public:
        MyIHClass() : translPtr(NULL), rotPtr(NULL) {
        }
        virtual ~MyIHClass() {}
        virtual void OnIdle() {
            bool someKeyIsPressed = false;
            if (keyPressed[UP]) {
                translPtr->GetTranslation(&soldadoTrans);
                if (soldadoTrans.GetY() < 30)
                    translPtr->MakeTranslation(soldadoTrans + Point4D(0, 0.01, 0, 0));
                    refvecRot = refvecRot + Point4D(0, 0.01, 0, 0);
                someKeyIsPressed = true;
            }
            if (keyPressed[DOWN]) {
                translPtr->GetTranslation(&soldadoTrans);
                if (soldadoTrans.GetY() > -30)
                    translPtr->MakeTranslation(soldadoTrans + Point4D(0, -0.01, 0, 0));
                    refvecRot = refvecRot + Point4D(0, -0.01, 0, 0);
                someKeyIsPressed = true;
            }
            if (keyPressed[LEFT]) {
                rotation = rotation + 2*PI/360;
                translPtr->GetVectorY(&refvecRot);
                rotPtr->MakeRotation(refvecRot, rotation);
                someKeyIsPressed = true;
            }
            if (keyPressed[RIGHT]) {
                rotation = rotation - 2*PI/360;
                translPtr->GetVectorY(&refvecRot);
                rotPtr->MakeRotation(refvecRot, rotation);
                someKeyIsPressed = true;
            }
            if (someKeyIsPressed)
                viewerPtr->PostRedisplay();
        }
        Transform* translPtr;
        Transform* rotPtr;
    protected:
    private:
        Point4D soldadoTrans;
        Point4D refvecRot;
        double rotation = 0.0;
};



// The application itself:
int main(int argc, char* argv[])
{
    ViewerGlutOGL::Init(&argc, argv); // Initialize GLUT
    static Scene scene; // create a scene
    static ViewerGlutOGL viewer; // create a viewer (application window)
    viewer.SetSize(854,480);
    // create a camera (scene observer)
    Camera camera(Point4D(0,8,10,1), Point4D(0,0,0,1), Point4D::Y());

    // Objects in the scene
    VART::MeshObject soldado;
    list<VART::MeshObject*> objects;
    VART::MeshObject::ReadFromOBJ("marine.obj", &objects);
    VART::Box floor;
    floor.MakeBox(-30, 30, -8, 0, -30, 30);
    floor.SetMaterial(VART::Material::DARK_PLASTIC_GRAY());

    // Build up the scene 
    Transform soldadoTrans, soldadoScale, soldadoRot1, soldadoRot2;
    soldadoScale.MakeScale(0.756972112, 0.756972112, 0.756972112);
    soldadoRot1.MakeXRotation(-PI/2);
    soldadoRot2.MakeIdentity();
    soldadoTrans.MakeTranslation(Point4D(0, 1, 0));
    list<VART::MeshObject*>::iterator iter = objects.begin();
    for (; iter != objects.end(); ++iter) {
        soldadoScale.AddChild(**iter);
    }
    //soldadoScale.AddChild(soldado);
    soldadoTrans.AddChild(soldadoScale);
    soldadoRot1.AddChild(soldadoTrans);
    soldadoRot2.AddChild(soldadoRot1);
    scene.AddObject(&soldadoRot2);
    scene.AddObject(&floor);

    scene.AddCamera(&camera);
    // Set up the viewer
    viewer.SetTitle("Soldado");
    viewer.SetScene(scene); // attach the scene
    KeyboardHandler kbh; // create a keyboard handler
    viewer.SetKbHandler(&kbh); // attach the keyboard handler
    MyIHClass idh;
    idh.translPtr = &soldadoTrans;
    idh.rotPtr = &soldadoRot2;

    viewer.SetIdleHandler(&idh);

    // Run application
    scene.DrawLightsOGL(); // Set OpenGL's lights' state
    ViewerGlutOGL::MainLoop(); // Enter main loop (event loop)
    return 0;
}
